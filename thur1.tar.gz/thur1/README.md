# cs320p2
name: thomas hur
b#: b0060038
status: complete
extra credit: least frequently used (LFU) implementation, using additional vectors<tag> and <frequency> to determine which entries get evicted from the cache. File is "extra-credit.cpp" and compiles into a separate binary called "extra-credit", which is run the same way as cache-sim

The LFU implementation in most cases outperforms the various LRU implementations at each level of associativity. In some cases, however, it does not. This could be due to the fact that frequencies of each tag, depending on the associativity/set split, are relatively close to one another, causing it to be no better, if not slightly worse, than LRU.